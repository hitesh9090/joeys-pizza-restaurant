import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCart } from "@/lib/cart";
import { toast } from "sonner";

export const Route = createFileRoute("/menu")({
  component: MenuPage,
  head: () => ({
    meta: [
      { title: "Menu — Joey's Pizza" },
      { name: "description", content: "Browse Joey's Pizza menu — wood-fired pizzas, starters, and desserts. Order for delivery or pickup in Andheri West, Mumbai." },
    ],
  }),
});

const FILTERS = [
  { id: "all", label: "All" },
  { id: "veg", label: "Veg Pizzas" },
  { id: "nonveg", label: "Non-Veg Pizzas" },
  { id: "starter", label: "Starters" },
  { id: "dessert", label: "Desserts" },
];

function MenuPage() {
  const [filter, setFilter] = useState("all");
  const { add } = useCart();

  const { data: items, isLoading } = useQuery({
    queryKey: ["menu_items"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("menu_items")
        .select("*")
        .eq("available", true)
        .order("sort_order");
      if (error) throw error;
      return data;
    },
  });

  const filtered = useMemo(() => {
    if (!items) return [];
    if (filter === "all") return items;
    return items.filter((i) => i.category === filter);
  }, [items, filter]);

  const handleAdd = (it: NonNullable<typeof items>[number], size: "small" | "large" | "single") => {
    const price = size === "small" ? Number(it.price_small) : Number(it.price_large);
    add({ id: it.id, name: it.name, price, size, image_url: it.image_url });
    toast.success(`${it.name} added to cart`);
  };

  return (
    <main className="min-h-screen bg-ink px-6 py-16 md:px-12">
      <div className="mx-auto max-w-6xl">
        <div className="text-center">
          <p className="kicker">The Menu</p>
          <h1 className="mt-4 font-display text-[clamp(2.2rem,5vw,3.8rem)]">Every Slice, a Statement</h1>
          <div className="gold-rule mx-auto mt-5" />
        </div>

        <div className="mt-12 flex flex-wrap justify-center gap-3">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`border px-5 py-2 text-[0.7rem] uppercase tracking-[0.18em] transition ${
                filter === f.id
                  ? "border-gold text-gold"
                  : "border-gold/25 text-cream/50 hover:border-gold hover:text-gold"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {isLoading ? (
          <p className="mt-16 text-center text-sm text-muted-foreground">Loading menu…</p>
        ) : (
          <div className="mt-12 grid gap-px bg-gold/10 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((it, idx) => {
              const hasSizes = it.price_small != null;
              return (
                <article
                  key={`${filter}-${it.id}`}
                  className="menu-card group bg-ink transition hover:bg-[oklch(0.18_0.012_60)]"
                  style={{ animationDelay: `${idx * 80}ms` }}
                >
                  <div className="relative h-52 overflow-hidden">
                    {it.image_url && (
                      <img
                        src={it.image_url}
                        alt={it.name}
                        loading="lazy"
                        style={{ animationDelay: `${(idx % 5) * 0.6}s` }}
                        className="menu-float h-full w-full object-cover brightness-90 saturate-110 transition duration-500 group-hover:scale-105"
                      />
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-ink/70 to-transparent" />
                    <span
                      className={`absolute left-3 top-3 border px-3 py-1 text-[0.6rem] uppercase tracking-[0.18em] ${
                        it.veg
                          ? "border-emerald-700/30 bg-emerald-900/15 text-emerald-400"
                          : "border-red-800/30 bg-red-900/15 text-red-300"
                      }`}
                    >
                      {it.veg ? "Veg" : "Non-Veg"}
                    </span>
                    {it.popular && (
                      <span className="absolute right-3 top-3 border border-gold/30 bg-gold/15 px-3 py-1 text-[0.6rem] uppercase tracking-[0.18em] text-gold">
                        {it.badge ?? "Popular"}
                      </span>
                    )}
                  </div>
                  <div className="p-5">
                    <h3 className="font-display text-2xl font-semibold">{it.name}</h3>
                    {it.description && <p className="mt-2 text-[0.78rem] leading-relaxed text-muted-foreground">{it.description}</p>}
                    <div className="mt-5 flex items-center justify-between gap-3">
                      <span className="font-display text-lg text-gold">
                        {hasSizes ? `₹${it.price_small} – ₹${it.price_large}` : `₹${it.price_large}`}
                      </span>
                      {hasSizes ? (
                        <div className="flex gap-1.5">
                          <button onClick={() => handleAdd(it, "small")} className="border border-gold/40 px-3 py-1.5 text-[0.65rem] uppercase tracking-[0.15em] text-gold transition hover:bg-gold hover:text-ink">
                            S
                          </button>
                          <button onClick={() => handleAdd(it, "large")} className="border border-gold/40 px-3 py-1.5 text-[0.65rem] uppercase tracking-[0.15em] text-gold transition hover:bg-gold hover:text-ink">
                            L
                          </button>
                        </div>
                      ) : (
                        <button onClick={() => handleAdd(it, "single")} className="border border-gold/40 px-4 py-1.5 text-[0.65rem] uppercase tracking-[0.15em] text-gold transition hover:bg-gold hover:text-ink">
                          Add +
                        </button>
                      )}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>
    </main>
  );
}
