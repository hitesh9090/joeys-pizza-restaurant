import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { useCart } from "@/lib/cart";
import { placeOrder } from "@/lib/orders.functions";
import { toast } from "sonner";

export const Route = createFileRoute("/checkout")({
  component: Checkout,
  head: () => ({ meta: [{ title: "Checkout — Joey's Pizza" }] }),
});

function Checkout() {
  const { items, subtotal, clear } = useCart();
  const navigate = useNavigate();
  const placeOrderFn = useServerFn(placeOrder);
  const [loading, setLoading] = useState(false);
  const [fulfillment, setFulfillment] = useState<"delivery" | "pickup">("delivery");
  const [payment, setPayment] = useState<"cash" | "card">("cash");

  const deliveryFee = fulfillment === "delivery" ? 40 : 0;
  const total = subtotal + deliveryFee;

  if (items.length === 0) {
    return (
      <main className="flex min-h-[60vh] flex-col items-center justify-center px-6 text-center">
        <h1 className="font-display text-4xl">Your cart is empty</h1>
        <p className="mt-3 text-sm text-muted-foreground">Add something delicious before checking out.</p>
        <Link to="/menu" className="btn-gold mt-8 inline-block">View Menu</Link>
      </main>
    );
  }

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (loading) return;
    const fd = new FormData(e.currentTarget);
    setLoading(true);
    try {
      const res = await placeOrderFn({
        data: {
          customer_name: String(fd.get("name") || ""),
          customer_phone: String(fd.get("phone") || ""),
          fulfillment,
          address: fulfillment === "delivery" ? String(fd.get("address") || "") : null,
          notes: String(fd.get("notes") || "") || null,
          payment_method: payment,
          items: items.map((i) => ({ id: i.id, size: i.size, qty: i.qty })),
        },
      });
      clear();
      toast.success(`Order #${res.order_number} placed!`);
      navigate({ to: "/order/$id", params: { id: res.id } });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Could not place order";
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-warm px-6 py-16 md:px-12">
      <div className="mx-auto max-w-5xl">
        <p className="kicker">Almost there</p>
        <h1 className="mt-3 font-display text-[clamp(2rem,4vw,3rem)]">Checkout</h1>
        <div className="gold-rule mt-4" />

        <form onSubmit={onSubmit} className="mt-12 grid gap-12 md:grid-cols-[1fr_380px]">
          {/* form */}
          <div className="space-y-8">
            <section>
              <h2 className="mb-5 font-display text-2xl">Your details</h2>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="label-gold">Name</label>
                  <input name="name" required maxLength={120} className="input-gold" placeholder="Your name" />
                </div>
                <div>
                  <label className="label-gold">Phone</label>
                  <input name="phone" required maxLength={20} pattern="[0-9+\-\s()]+" className="input-gold" placeholder="+91 98200 12345" />
                </div>
              </div>
            </section>

            <section>
              <h2 className="mb-5 font-display text-2xl">How would you like it?</h2>
              <div className="mb-5 grid grid-cols-2 gap-3">
                {(["delivery", "pickup"] as const).map((f) => (
                  <button
                    type="button"
                    key={f}
                    onClick={() => setFulfillment(f)}
                    className={`border px-5 py-4 text-left text-sm uppercase tracking-[0.15em] transition ${
                      fulfillment === f ? "border-gold bg-gold/5 text-gold" : "border-gold/25 text-cream/60 hover:border-gold/60"
                    }`}
                  >
                    {f}
                    <div className="mt-1 text-[0.65rem] normal-case tracking-normal text-muted-foreground">
                      {f === "delivery" ? "₹40 delivery fee" : "Free · ready in 25 min"}
                    </div>
                  </button>
                ))}
              </div>
              {fulfillment === "delivery" && (
                <div>
                  <label className="label-gold">Delivery address</label>
                  <textarea name="address" required maxLength={500} rows={3} className="input-gold" placeholder="Flat / building / street, area, landmark" />
                </div>
              )}
              <div className="mt-4">
                <label className="label-gold">Notes (optional)</label>
                <textarea name="notes" maxLength={500} rows={2} className="input-gold" placeholder="Less spicy, no onions, etc." />
              </div>
            </section>

            <section>
              <h2 className="mb-5 font-display text-2xl">Payment</h2>
              <div className="grid grid-cols-2 gap-3">
                {(["cash", "card"] as const).map((p) => (
                  <button
                    type="button"
                    key={p}
                    onClick={() => setPayment(p)}
                    className={`border px-5 py-4 text-left text-sm uppercase tracking-[0.15em] transition ${
                      payment === p ? "border-gold bg-gold/5 text-gold" : "border-gold/25 text-cream/60 hover:border-gold/60"
                    }`}
                  >
                    {p === "cash" ? "Cash on delivery" : "Pay online (card)"}
                    <div className="mt-1 text-[0.65rem] normal-case tracking-normal text-muted-foreground">
                      {p === "cash" ? "Pay when it arrives" : "Coming soon — secure card checkout"}
                    </div>
                  </button>
                ))}
              </div>
              {payment === "card" && (
                <p className="mt-3 text-xs text-muted-foreground">
                  Online card payment is being set up. For now, please choose Cash on delivery.
                </p>
              )}
            </section>
          </div>

          {/* summary */}
          <aside className="h-fit border border-border/40 bg-ink p-7">
            <h3 className="font-display text-2xl">Order summary</h3>
            <ul className="mt-5 space-y-3 border-b border-border/30 pb-5">
              {items.map((i) => (
                <li key={`${i.id}-${i.size}`} className="flex justify-between text-sm">
                  <span className="text-cream/80">{i.qty}× {i.name} <span className="text-muted-foreground">({i.size})</span></span>
                  <span className="text-gold">₹{i.qty * i.price}</span>
                </li>
              ))}
            </ul>
            <div className="mt-5 space-y-2 text-sm">
              <div className="flex justify-between text-muted-foreground"><span>Subtotal</span><span>₹{subtotal}</span></div>
              <div className="flex justify-between text-muted-foreground"><span>{fulfillment === "delivery" ? "Delivery" : "Pickup"}</span><span>{deliveryFee ? `₹${deliveryFee}` : "Free"}</span></div>
              <div className="flex justify-between border-t border-border/30 pt-3 text-base">
                <span className="uppercase tracking-[0.15em]">Total</span>
                <span className="font-display text-2xl text-gold">₹{total}</span>
              </div>
            </div>
            <button
              type="submit"
              disabled={loading || payment === "card"}
              className="btn-gold mt-6 w-full"
            >
              {loading ? "Placing order…" : payment === "card" ? "Card payment coming soon" : "Place order"}
            </button>
          </aside>
        </form>
      </div>
    </main>
  );
}
