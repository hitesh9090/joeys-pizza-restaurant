import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, MapPin, Clock, Phone } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Home,
});

const reviews = [
  { name: "Aarav S.", initial: "A", text: "Joey's Special is unreal. The crust has that proper wood-fire chew. Best in Andheri, no question.", meta: "Local Guide · 312 reviews" },
  { name: "Priya K.", initial: "P", text: "Ordered the Paneer Makhani for a family dinner — everyone went silent. That's how you know it's good.", meta: "2 weeks ago" },
  { name: "Rohan M.", initial: "R", text: "Late night cravings sorted. Open till 12, hot and quick. The garlic bread alone is worth a trip.", meta: "Top contributor" },
];

function Home() {
  return (
    <main>
      {/* HERO */}
      <section className="relative grid min-h-[88vh] gap-12 overflow-hidden px-6 py-16 md:grid-cols-2 md:px-16 md:py-0">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_70%_50%,oklch(0.50_0.16_25/0.18)_0%,transparent_70%)]" />
        <div className="relative z-10 flex flex-col justify-center">
          <div className="eyebrow mb-6 flex items-center gap-3">
            <span className="h-px w-8 bg-gold" />
            Andheri West · Mumbai
          </div>
          <h1 className="font-display text-[clamp(3rem,7vw,6rem)] leading-[0.92] tracking-tight">
            Crafted with<br />
            <strong className="block font-bold text-gold">Fire &amp; Passion</strong>
          </h1>
          <p className="mt-6 max-w-md text-sm leading-loose text-cream/60">
            Real dough. Real toppings. Real heat. Joey's Pizza has been Mumbai's most-loved slice since the very first oven fired up on D.N. Nagar.
          </p>
          <div className="mt-10 flex flex-wrap items-center gap-5">
            <Link to="/menu" className="btn-gold inline-block">Explore Menu</Link>
            <a href="#location" className="group flex items-center gap-2 text-sm tracking-wide text-cream/70 transition hover:text-cream">
              Find Us
              <ArrowRight size={16} className="transition group-hover:translate-x-1" />
            </a>
          </div>
          <div className="mt-12 flex gap-10 border-t border-gold/15 pt-8">
            <div><div className="font-display text-3xl font-semibold text-gold">4.4</div><div className="mt-1 text-[0.65rem] uppercase tracking-[0.2em] text-muted-foreground">Google Rating</div></div>
            <div><div className="font-display text-3xl font-semibold text-gold">24K+</div><div className="mt-1 text-[0.65rem] uppercase tracking-[0.2em] text-muted-foreground">Reviews</div></div>
            <div><div className="font-display text-3xl font-semibold text-gold">₹200</div><div className="mt-1 text-[0.65rem] uppercase tracking-[0.2em] text-muted-foreground">Starts At</div></div>
          </div>
        </div>

        <div className="relative hidden items-center justify-center md:flex">
          <div className="relative h-[480px] w-[480px]">
            <div className="absolute inset-0 flex animate-slowspin items-center justify-center">
              <img
                src="https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=460&h=460&fit=crop&crop=center"
                alt="Wood-fired pizza"
                className="h-[400px] w-[400px] rounded-full border-2 border-gold/20 object-cover"
              />
            </div>
            <div className="absolute right-[-10px] top-[30px] animate-float border border-gold/30 bg-ink/95 px-4 py-3 backdrop-blur">
              <span className="block text-[0.65rem] uppercase tracking-[0.18em] text-gold">Most Popular</span>
              <span className="font-display text-lg font-semibold text-cream">Joey's Special</span>
            </div>
            <div className="absolute bottom-[50px] left-[-20px] animate-float-2 border border-gold/30 bg-ink/95 px-4 py-3 backdrop-blur">
              <span className="block text-[0.65rem] uppercase tracking-[0.18em] text-gold">Open Until</span>
              <span className="font-display text-lg font-semibold text-cream">12 AM Daily</span>
            </div>
            <div className="absolute right-[-35px] top-[55%] animate-float-3 border border-gold/30 bg-ink/95 px-4 py-3 backdrop-blur">
              <span className="block text-[0.65rem] uppercase tracking-[0.18em] text-gold">Halal</span>
              <span className="font-display text-lg font-semibold text-cream">Certified</span>
            </div>
          </div>
        </div>
      </section>

      {/* STORY */}
      <section id="story" className="bg-ink px-6 py-24 md:px-12">
        <div className="mx-auto grid max-w-5xl gap-16 md:grid-cols-2 md:items-center">
          <div>
            <p className="kicker mb-4">Our Story</p>
            <h2 className="font-display text-[clamp(2rem,4vw,3rem)]">A Slice of Mumbai,<br />Since Day One.</h2>
            <div className="my-6 h-px w-16 bg-gold" />
            <p className="text-sm leading-loose text-cream/60">
              We started with one oven, a sourdough starter that's been alive longer than most of our staff, and a stubborn belief that pizza should taste like somebody made it for you. Twenty years on, that's still all we do.
            </p>
            <div className="mt-8 flex flex-wrap gap-2">
              {["Wood-fired", "Sourdough crust", "Halal certified", "Daily fresh"].map((p) => (
                <span key={p} className="border border-gold/30 px-4 py-2 text-[0.7rem] tracking-wide text-cream/70">{p}</span>
              ))}
            </div>
          </div>
          <img src="https://images.unsplash.com/photo-1513104890138-7c749659a591?w=700&h=600&fit=crop" alt="Inside the kitchen" className="h-[500px] w-full object-cover" />
        </div>
      </section>

      {/* REVIEWS */}
      <section id="reviews" className="bg-warm px-6 py-24 md:px-12">
        <div className="mx-auto max-w-5xl">
          <div className="text-center">
            <p className="kicker">What People Say</p>
            <h2 className="mt-4 font-display text-[clamp(2rem,4vw,3rem)]">Loved Across the City</h2>
            <div className="gold-rule mx-auto mt-5" />
          </div>
          <div className="mt-14 grid gap-px bg-gold/10 md:grid-cols-3">
            {reviews.map((r) => (
              <div key={r.name} className="relative overflow-hidden bg-warm p-8">
                <span className="pointer-events-none absolute -top-3 left-4 font-display text-7xl text-gold/10">"</span>
                <div className="mb-3 tracking-[0.3em] text-gold">★★★★★</div>
                <p className="mb-6 text-sm italic leading-relaxed text-cream/65">{r.text}</p>
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center bg-[var(--red-brand)] font-display font-bold text-cream">{r.initial}</div>
                  <div>
                    <div className="text-sm text-cream">{r.name}</div>
                    <div className="text-[0.7rem] text-muted-foreground">{r.meta}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* LOCATION */}
      <section id="location" className="bg-ink px-6 py-24 md:px-12">
        <div className="mx-auto max-w-5xl">
          <div className="text-center">
            <p className="kicker">Visit Us</p>
            <h2 className="mt-4 font-display text-[clamp(2rem,4vw,3rem)]">Come Say Hi</h2>
            <div className="gold-rule mx-auto mt-5" />
          </div>
          <div className="mt-14 grid gap-12 md:grid-cols-2">
            <div className="flex flex-col gap-7">
              {[
                { icon: <MapPin size={16} />, label: "Address", val: "Shop 4, D.N. Nagar, Andheri West, Mumbai 400053" },
                { icon: <Clock size={16} />, label: "Hours", val: "11:00 AM – 12:00 AM · All days" },
                { icon: <Phone size={16} />, label: "Reservations", val: "+91 98200 12345" },
              ].map((row) => (
                <div key={row.label} className="flex gap-4">
                  <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center border border-gold/30 text-gold">{row.icon}</div>
                  <div>
                    <div className="label-gold mb-1">{row.label}</div>
                    <div className="text-sm leading-relaxed text-cream/70">{row.val}</div>
                  </div>
                </div>
              ))}
              <Link to="/menu" className="btn-gold mt-4 self-start">Order Now</Link>
            </div>
            <div className="relative flex h-[360px] flex-col items-center justify-center gap-3 border border-gold/15 bg-ink/80">
              <div className="absolute inset-0 bg-[repeating-linear-gradient(45deg,oklch(0.74_0.12_85/0.02)_0,oklch(0.74_0.12_85/0.02)_1px,transparent_1px,transparent_40px),repeating-linear-gradient(-45deg,oklch(0.74_0.12_85/0.02)_0,oklch(0.74_0.12_85/0.02)_1px,transparent_1px,transparent_40px)]" />
              <div className="relative flex h-12 w-12 items-center justify-center bg-[var(--red-brand)] text-xl text-cream" style={{ animation: "pinbob 2s ease-in-out infinite alternate" }}>
                <MapPin size={22} />
              </div>
              <div className="relative max-w-[240px] text-center text-sm leading-relaxed text-cream/55">
                D.N. Nagar, Andheri West<br />Mumbai 400053
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="flex flex-col items-center justify-between gap-3 border-t border-gold/10 bg-ink px-6 py-8 text-center md:flex-row md:px-12 md:text-left">
        <div className="font-display text-lg font-bold tracking-[2px]">Joey's<span className="text-gold">Pizza</span></div>
        <div className="text-[0.7rem] tracking-wide text-muted-foreground">© {new Date().getFullYear()} Joey's Pizza · Andheri West, Mumbai</div>
      </footer>
    </main>
  );
}
