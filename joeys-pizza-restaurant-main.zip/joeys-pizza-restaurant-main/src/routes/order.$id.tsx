import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import { CheckCircle2, ChefHat, Package, Bike, PartyPopper, XCircle } from "lucide-react";
import { getOrder } from "@/lib/orders.functions";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/order/$id")({
  component: OrderConfirmation,
  head: () => ({ meta: [{ title: "Order confirmed — Joey's Pizza" }] }),
});

type Step = { key: string; label: string; icon: typeof CheckCircle2 };

function getStepsFor(fulfillment: string): Step[] {
  const base: Step[] = [
    { key: "new", label: "Order received", icon: CheckCircle2 },
    { key: "preparing", label: "Preparing in the kitchen", icon: ChefHat },
    { key: "ready", label: fulfillment === "delivery" ? "Ready — packing up" : "Ready for pickup", icon: Package },
  ];
  if (fulfillment === "delivery") {
    base.push({ key: "out_for_delivery", label: "Out for delivery", icon: Bike });
  }
  base.push({ key: "completed", label: fulfillment === "delivery" ? "Delivered — enjoy!" : "Picked up — enjoy!", icon: PartyPopper });
  return base;
}

function OrderConfirmation() {
  const { id } = Route.useParams();
  const fetchOrder = useServerFn(getOrder);
  const queryClient = useQueryClient();
  const { data: order, isLoading } = useQuery({
    queryKey: ["order", id],
    queryFn: () => fetchOrder({ data: { id } }),
    refetchInterval: 20000,
  });

  // Live updates via realtime
  useEffect(() => {
    const channel = supabase
      .channel(`order-${id}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "orders", filter: `id=eq.${id}` },
        () => queryClient.invalidateQueries({ queryKey: ["order", id] })
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [id, queryClient]);

  if (isLoading) return <p className="py-32 text-center text-sm text-muted-foreground">Loading…</p>;
  if (!order) return <p className="py-32 text-center text-sm text-muted-foreground">Order not found.</p>;

  const items = order.items as Array<{ name: string; size: string; qty: number; price: number }>;
  const status = order.order_status as string;
  const cancelled = status === "cancelled";
  const steps = getStepsFor(order.fulfillment);
  const currentIdx = cancelled ? -1 : Math.max(0, steps.findIndex((s) => s.key === status));

  return (
    <main className="min-h-screen bg-warm px-6 py-20 md:px-12">
      <div className="mx-auto max-w-xl border border-border/40 bg-ink p-10 text-center">
        <CheckCircle2 size={48} className="mx-auto text-gold" />
        <p className="kicker mt-6">Order confirmed</p>
        <h1 className="mt-3 font-display text-4xl">Thank you, {order.customer_name.split(" ")[0]}!</h1>
        <p className="mt-3 text-sm text-muted-foreground">
          Order <span className="text-gold">#{order.order_number}</span> · {order.fulfillment === "delivery" ? "Delivery" : "Pickup"} · ETA ~ 30 min
        </p>

        {/* Status tracker */}
        <div className="my-10 text-left">
          <p className="kicker mb-5 text-center">
            {cancelled ? "Order cancelled" : "Live status"}
          </p>
          {cancelled ? (
            <div className="flex items-center justify-center gap-3 border border-destructive/40 p-4 text-destructive">
              <XCircle size={20} />
              <span className="text-sm">This order was cancelled. Please contact us if this is unexpected.</span>
            </div>
          ) : (
            <ol className="space-y-4">
              {steps.map((step, idx) => {
                const Icon = step.icon;
                const done = idx < currentIdx;
                const active = idx === currentIdx;
                return (
                  <li key={step.key} className="flex items-center gap-4">
                    <div
                      className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full border transition-all ${
                        done
                          ? "border-gold bg-gold/20 text-gold"
                          : active
                          ? "border-gold bg-gold text-ink animate-pulse"
                          : "border-border/40 bg-ink text-muted-foreground"
                      }`}
                    >
                      <Icon size={18} />
                    </div>
                    <div className="flex-1">
                      <div
                        className={`text-sm ${
                          done || active ? "text-cream" : "text-muted-foreground"
                        }`}
                      >
                        {step.label}
                      </div>
                      {active && (
                        <div className="mt-0.5 text-[0.65rem] uppercase tracking-[0.18em] text-gold">
                          In progress
                        </div>
                      )}
                    </div>
                  </li>
                );
              })}
            </ol>
          )}
        </div>

        <div className="my-8 h-px w-12 bg-gold mx-auto" />

        <ul className="space-y-2 text-left text-sm">
          {items.map((i, idx) => (
            <li key={idx} className="flex justify-between">
              <span>{i.qty}× {i.name} <span className="text-muted-foreground">({i.size})</span></span>
              <span className="text-gold">₹{i.qty * i.price}</span>
            </li>
          ))}
        </ul>
        <div className="mt-5 flex justify-between border-t border-border/30 pt-4">
          <span className="text-sm uppercase tracking-[0.15em]">Total</span>
          <span className="font-display text-2xl text-gold">₹{Number(order.total).toFixed(0)}</span>
        </div>
        <p className="mt-6 text-xs text-muted-foreground">
          Payment: {order.payment_method === "cash" ? "Cash on delivery" : "Paid online"}
        </p>

        <Link to="/" className="btn-ghost-gold mt-8 inline-block">Back to home</Link>
      </div>
    </main>
  );
}
