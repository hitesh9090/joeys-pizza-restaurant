import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState } from "react";
import { adminListOrders, adminUpdateStatus } from "@/lib/orders.functions";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/admin")({
  component: AdminPage,
  head: () => ({ meta: [{ title: "Admin — Joey's Pizza" }, { name: "robots", content: "noindex" }] }),
});

type Order = Awaited<ReturnType<typeof adminListOrders>>[number];

const STATUSES = ["new", "preparing", "ready", "out_for_delivery", "completed", "cancelled"] as const;

function AdminPage() {
  const [password, setPassword] = useState("");
  const [authed, setAuthed] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(false);
  const listFn = useServerFn(adminListOrders);
  const updateFn = useServerFn(adminUpdateStatus);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const knownIdsRef = useRef<Set<string>>(new Set());

  const load = async (pw: string) => {
    setLoading(true);
    try {
      const data = await listFn({ data: { password: pw } });
      setOrders(data);
      knownIdsRef.current = new Set(data.map((o) => o.id));
      setAuthed(true);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Login failed");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!authed) return;
    const channel = supabase
      .channel("admin-orders")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "orders" }, (payload) => {
        const newOrder = payload.new as Order;
        if (knownIdsRef.current.has(newOrder.id)) return;
        knownIdsRef.current.add(newOrder.id);
        setOrders((prev) => [newOrder, ...prev]);
        audioRef.current?.play().catch(() => {});
        toast.success(`New order #${newOrder.order_number}`);
      })
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "orders" }, (payload) => {
        const updated = payload.new as Order;
        setOrders((prev) => prev.map((o) => (o.id === updated.id ? updated : o)));
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [authed]);

  const setStatus = async (id: string, status: typeof STATUSES[number]) => {
    try {
      await updateFn({ data: { password, id, order_status: status } });
      setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, order_status: status } : o)));
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Update failed");
    }
  };

  if (!authed) {
    return (
      <main className="flex min-h-[70vh] items-center justify-center px-6">
        <form
          onSubmit={(e) => { e.preventDefault(); load(password); }}
          className="w-full max-w-sm border border-border/40 bg-ink p-8"
        >
          <p className="kicker">Staff only</p>
          <h1 className="mt-3 font-display text-3xl">Owner Dashboard</h1>
          <label className="label-gold mt-6">Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="input-gold"
            autoFocus
          />
          <button type="submit" disabled={loading} className="btn-gold mt-6 w-full">
            {loading ? "Checking…" : "Sign in"}
          </button>
        </form>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-warm px-6 py-12 md:px-12">
      {/* short notification beep */}
      <audio ref={audioRef} src="data:audio/wav;base64,UklGRl9vT19XQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAA" />
      <div className="mx-auto max-w-6xl">
        <div className="flex items-end justify-between">
          <div>
            <p className="kicker">Live</p>
            <h1 className="mt-2 font-display text-4xl">Orders</h1>
          </div>
          <button onClick={() => load(password)} className="btn-ghost-gold">Refresh</button>
        </div>

        <div className="mt-10 grid gap-4">
          {orders.length === 0 && <p className="text-sm text-muted-foreground">No orders yet.</p>}
          {orders.map((o) => {
            const items = o.items as Array<{ name: string; size: string; qty: number; price: number }>;
            return (
              <article key={o.id} className="grid gap-5 border border-border/40 bg-ink p-6 md:grid-cols-[120px_1fr_220px]">
                <div>
                  <div className="font-display text-3xl text-gold">#{o.order_number}</div>
                  <div className="mt-1 text-[0.65rem] uppercase tracking-[0.18em] text-muted-foreground">
                    {new Date(o.created_at).toLocaleTimeString()}
                  </div>
                  <div className={`mt-3 inline-block px-2 py-0.5 text-[0.6rem] uppercase tracking-[0.15em] ${o.order_status === "new" ? "bg-gold text-ink" : "border border-gold/40 text-gold"}`}>
                    {o.order_status}
                  </div>
                </div>
                <div className="text-sm">
                  <div className="font-medium text-cream">{o.customer_name} · {o.customer_phone}</div>
                  <div className="text-muted-foreground">{o.fulfillment === "delivery" ? `Delivery → ${o.address}` : "Pickup"}</div>
                  <ul className="mt-3 space-y-1">
                    {items.map((i, idx) => (
                      <li key={idx} className="text-cream/80">{i.qty}× {i.name} <span className="text-muted-foreground">({i.size})</span> — ₹{i.qty * i.price}</li>
                    ))}
                  </ul>
                  {o.notes && <p className="mt-2 text-xs italic text-muted-foreground">Note: {o.notes}</p>}
                  <div className="mt-3 text-sm">
                    <span className="text-muted-foreground">Total: </span>
                    <span className="font-display text-xl text-gold">₹{Number(o.total).toFixed(0)}</span>
                    <span className="ml-3 text-xs text-muted-foreground">{o.payment_method === "cash" ? "Cash on delivery" : "Paid online"}</span>
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  {STATUSES.map((s) => (
                    <button
                      key={s}
                      onClick={() => setStatus(o.id, s)}
                      disabled={o.order_status === s}
                      className={`px-3 py-2 text-[0.7rem] uppercase tracking-[0.15em] transition ${
                        o.order_status === s
                          ? "border border-gold bg-gold/10 text-gold"
                          : "border border-border/40 text-cream/60 hover:border-gold hover:text-gold"
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </main>
  );
}
