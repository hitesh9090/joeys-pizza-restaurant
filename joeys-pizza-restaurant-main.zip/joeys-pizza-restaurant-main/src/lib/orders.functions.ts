import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { sendOwnerWhatsApp, formatOrderMessage } from "./whatsapp.server";

const orderItemSchema = z.object({
  id: z.string().uuid(),
  size: z.enum(["small", "large", "single"]),
  qty: z.number().int().min(1).max(20),
});

const placeOrderSchema = z.object({
  customer_name: z.string().trim().min(1).max(120),
  customer_phone: z.string().trim().min(5).max(20).regex(/^[0-9+\-\s()]+$/),
  fulfillment: z.enum(["delivery", "pickup"]),
  address: z.string().trim().max(500).optional().nullable(),
  notes: z.string().trim().max(500).optional().nullable(),
  payment_method: z.enum(["cash", "card"]),
  items: z.array(orderItemSchema).min(1).max(50),
});

export const placeOrder = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => placeOrderSchema.parse(data))
  .handler(async ({ data }) => {
    if (data.fulfillment === "delivery" && (!data.address || data.address.length < 5)) {
      throw new Error("Delivery address is required");
    }

    // Look up live prices from DB — never trust client prices
    const ids = Array.from(new Set(data.items.map((i) => i.id)));
    const { data: menu, error: menuErr } = await supabaseAdmin
      .from("menu_items")
      .select("id, name, price_small, price_large, available, image_url")
      .in("id", ids);

    if (menuErr) {
      console.error("menu lookup", menuErr);
      throw new Error("Could not load menu");
    }

    const menuById = new Map(menu?.map((m) => [m.id, m]) ?? []);
    const enriched = data.items.map((it) => {
      const m = menuById.get(it.id);
      if (!m || !m.available) throw new Error("One of the items is unavailable");
      const unit = it.size === "small" ? Number(m.price_small ?? m.price_large) : Number(m.price_large);
      if (!unit || unit <= 0) throw new Error("Invalid item price");
      return { id: m.id, name: m.name, size: it.size, qty: it.qty, price: unit };
    });

    const subtotal = enriched.reduce((s, i) => s + i.price * i.qty, 0);
    const deliveryFee = data.fulfillment === "delivery" ? 40 : 0;
    const total = subtotal + deliveryFee;

    const { data: inserted, error: insErr } = await supabaseAdmin
      .from("orders")
      .insert({
        customer_name: data.customer_name,
        customer_phone: data.customer_phone,
        fulfillment: data.fulfillment,
        address: data.fulfillment === "delivery" ? data.address : null,
        notes: data.notes ?? null,
        items: enriched,
        subtotal,
        total,
        payment_method: data.payment_method,
        payment_status: data.payment_method === "cash" ? "cod" : "pending",
        order_status: "new",
      })
      .select("id, order_number, total")
      .single();

    if (insErr || !inserted) {
      console.error("insert order", insErr);
      throw new Error("Could not save order");
    }

    // Fire WhatsApp notification for cash orders immediately (card orders notify post-payment).
    if (data.payment_method === "cash") {
      const msg = formatOrderMessage({
        order_number: inserted.order_number,
        customer_name: data.customer_name,
        customer_phone: data.customer_phone,
        fulfillment: data.fulfillment,
        address: data.fulfillment === "delivery" ? data.address ?? null : null,
        items: enriched,
        total,
        payment_method: "cash",
        notes: data.notes ?? null,
      });
      const result = await sendOwnerWhatsApp(msg);
      if (result.ok) {
        await supabaseAdmin.from("orders").update({ notified: true }).eq("id", inserted.id);
      }
    }

    return { id: inserted.id, order_number: inserted.order_number, total: inserted.total };
  });

export const getOrder = createServerFn({ method: "GET" })
  .inputValidator((data: { id: string }) => z.object({ id: z.string().uuid() }).parse(data))
  .handler(async ({ data }) => {
    const { data: order, error } = await supabaseAdmin
      .from("orders")
      .select("*")
      .eq("id", data.id)
      .single();
    if (error || !order) throw new Error("Order not found");
    return order;
  });

export const adminListOrders = createServerFn({ method: "POST" })
  .inputValidator((data: { password: string }) => z.object({ password: z.string().min(1).max(200) }).parse(data))
  .handler(async ({ data }) => {
    const expected = process.env.ADMIN_PASSWORD;
    if (!expected) throw new Error("Admin password not configured");
    if (data.password !== expected) throw new Error("Invalid password");
    const { data: orders, error } = await supabaseAdmin
      .from("orders")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) throw new Error("Could not load orders");
    return orders;
  });

export const adminUpdateStatus = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) =>
    z
      .object({
        password: z.string().min(1).max(200),
        id: z.string().uuid(),
        order_status: z.enum(["new", "preparing", "ready", "out_for_delivery", "completed", "cancelled"]),
      })
      .parse(data)
  )
  .handler(async ({ data }) => {
    const expected = process.env.ADMIN_PASSWORD;
    if (!expected || data.password !== expected) throw new Error("Unauthorized");
    const { error } = await supabaseAdmin
      .from("orders")
      .update({ order_status: data.order_status })
      .eq("id", data.id);
    if (error) throw new Error("Could not update");
    return { ok: true };
  });
