// Server-only helper for sending WhatsApp messages via the Twilio connector gateway.
// Returns { ok: true } on success, { ok: false, reason } if not configured / failed.

const GATEWAY_URL = "https://connector-gateway.lovable.dev/twilio";

export type WhatsAppResult = { ok: true } | { ok: false; reason: string };

export async function sendOwnerWhatsApp(message: string): Promise<WhatsAppResult> {
  const LOVABLE_API_KEY = process.env.LOVABLE_API_KEY;
  const TWILIO_API_KEY = process.env.TWILIO_API_KEY;
  const FROM = process.env.TWILIO_WHATSAPP_FROM; // e.g. "whatsapp:+14155238886"
  const TO = process.env.OWNER_WHATSAPP_TO; // e.g. "whatsapp:+91XXXXXXXXXX"

  if (!LOVABLE_API_KEY) return { ok: false, reason: "LOVABLE_API_KEY missing" };
  if (!TWILIO_API_KEY) return { ok: false, reason: "Twilio not connected yet" };
  if (!FROM) return { ok: false, reason: "TWILIO_WHATSAPP_FROM not set" };
  if (!TO) return { ok: false, reason: "OWNER_WHATSAPP_TO not set" };

  try {
    const res = await fetch(`${GATEWAY_URL}/Messages.json`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "X-Connection-Api-Key": TWILIO_API_KEY,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({ From: FROM, To: TO, Body: message }),
    });
    if (!res.ok) {
      const text = await res.text();
      console.error("[whatsapp] Twilio error", res.status, text);
      return { ok: false, reason: `Twilio ${res.status}` };
    }
    return { ok: true };
  } catch (err) {
    console.error("[whatsapp] send failed", err);
    return { ok: false, reason: "network error" };
  }
}

export function formatOrderMessage(order: {
  order_number: number;
  customer_name: string;
  customer_phone: string;
  fulfillment: string;
  address: string | null;
  items: Array<{ name: string; size: string; qty: number; price: number }>;
  total: number;
  payment_method: string;
  notes: string | null;
}) {
  const lines = [
    `🍕 NEW ORDER #${order.order_number}`,
    ``,
    `${order.customer_name} · ${order.customer_phone}`,
    `${order.fulfillment === "delivery" ? "Delivery" : "Pickup"}${order.address ? ` → ${order.address}` : ""}`,
    ``,
    `Items:`,
    ...order.items.map((i) => `• ${i.qty}× ${i.name} (${i.size}) — ₹${(i.price * i.qty).toFixed(0)}`),
    ``,
    `TOTAL: ₹${order.total.toFixed(0)}`,
    `Payment: ${order.payment_method === "cash" ? "Cash on delivery" : "Paid online"}`,
  ];
  if (order.notes) lines.push(``, `Note: ${order.notes}`);
  return lines.join("\n");
}
