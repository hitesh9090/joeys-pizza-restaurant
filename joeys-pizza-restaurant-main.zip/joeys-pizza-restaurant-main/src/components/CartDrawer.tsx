import { Link } from "@tanstack/react-router";
import { X, Plus, Minus, Trash2 } from "lucide-react";
import { useCart } from "@/lib/cart";

export function CartDrawer() {
  const { items, open, setOpen, setQty, remove, subtotal } = useCart();

  return (
    <>
      <div
        onClick={() => setOpen(false)}
        className={`fixed inset-0 z-50 bg-black/60 transition-opacity ${open ? "opacity-100" : "pointer-events-none opacity-0"}`}
      />
      <aside
        className={`fixed right-0 top-0 z-50 flex h-full w-full max-w-md flex-col border-l border-border/40 bg-ink transition-transform ${open ? "translate-x-0" : "translate-x-full"}`}
      >
        <div className="flex items-center justify-between border-b border-border/40 px-6 py-5">
          <h3 className="font-display text-2xl">Your Cart</h3>
          <button onClick={() => setOpen(false)} className="text-cream/60 hover:text-gold"><X size={20} /></button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {items.length === 0 ? (
            <p className="mt-12 text-center text-sm text-muted-foreground">Your cart is empty.<br />Add something delicious from the menu.</p>
          ) : (
            <ul className="space-y-5">
              {items.map((it) => (
                <li key={`${it.id}-${it.size}`} className="flex gap-4 border-b border-border/30 pb-5">
                  {it.image_url && <img src={it.image_url} alt={it.name} className="h-16 w-16 flex-shrink-0 object-cover" />}
                  <div className="flex-1">
                    <div className="font-display text-lg leading-tight">{it.name}</div>
                    <div className="text-[0.7rem] uppercase tracking-[0.15em] text-muted-foreground">{it.size}</div>
                    <div className="mt-2 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <button onClick={() => setQty(it.id, it.size, it.qty - 1)} className="border border-border p-1 text-gold hover:bg-gold hover:text-ink"><Minus size={12} /></button>
                        <span className="w-6 text-center text-sm">{it.qty}</span>
                        <button onClick={() => setQty(it.id, it.size, it.qty + 1)} className="border border-border p-1 text-gold hover:bg-gold hover:text-ink"><Plus size={12} /></button>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="font-display text-lg text-gold">₹{it.price * it.qty}</span>
                        <button onClick={() => remove(it.id, it.size)} className="text-muted-foreground hover:text-destructive"><Trash2 size={14} /></button>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {items.length > 0 && (
          <div className="border-t border-border/40 p-6">
            <div className="mb-4 flex items-center justify-between text-sm">
              <span className="uppercase tracking-[0.15em] text-muted-foreground">Subtotal</span>
              <span className="font-display text-2xl text-gold">₹{subtotal}</span>
            </div>
            <Link to="/checkout" onClick={() => setOpen(false)} className="btn-gold block w-full text-center">
              Checkout
            </Link>
          </div>
        )}
      </aside>
    </>
  );
}
