import { Link } from "@tanstack/react-router";
import { ShoppingBag } from "lucide-react";
import { useCart } from "@/lib/cart";

export function SiteNav() {
  const { count, setOpen } = useCart();
  return (
    <nav className="sticky top-0 z-50 flex items-center justify-between border-b border-border/40 bg-[oklch(0.20_0.018_50/0.85)] px-6 py-5 backdrop-blur md:px-12">
      <Link to="/" className="font-display text-xl font-bold tracking-[2px] text-cream">
        Joey's<span className="text-gold">Pizza</span>
      </Link>
      <ul className="hidden gap-10 text-[0.78rem] uppercase tracking-[0.15em] text-cream/55 md:flex">
        <li><Link to="/menu" className="transition hover:text-gold">Menu</Link></li>
        <li><Link to="/" hash="story" className="transition hover:text-gold">Story</Link></li>
        <li><Link to="/" hash="reviews" className="transition hover:text-gold">Reviews</Link></li>
        <li><Link to="/" hash="location" className="transition hover:text-gold">Visit</Link></li>
      </ul>
      <button
        onClick={() => setOpen(true)}
        className="relative flex items-center gap-2 border border-gold px-5 py-2 text-[0.72rem] uppercase tracking-[0.18em] text-gold transition hover:bg-gold hover:text-ink"
      >
        <ShoppingBag size={14} />
        Cart
        {count > 0 && (
          <span className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-gold text-[0.65rem] font-semibold text-ink">
            {count}
          </span>
        )}
      </button>
    </nav>
  );
}
