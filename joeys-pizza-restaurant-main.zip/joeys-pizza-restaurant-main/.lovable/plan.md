## Animate menu items — gentle float + fade-in on scroll

Bring the menu page to life with subtle motion that fits the premium dark/gold aesthetic. No new dependencies — pure CSS keyframes added to `src/styles.css` and applied via classes on the menu cards.

### What it will look like

- **Fade-up on entry** — as you scroll, each pizza card fades in and rises ~16px into place. Cards animate in a staggered cascade (≈80ms apart) so the grid feels alive instead of popping in all at once.
- **Continuous gentle float** — once visible, each card's pizza **image** drifts up and down by a few pixels on a slow ~6s loop, with a slight rotation. Each card uses a slightly different delay so they don't move in lockstep — feels organic, like the pizzas are gently hovering.
- **Filter changes** — when the user switches filter (All / Veg / Non-Veg / etc.), the new set fades-up again with the same stagger.
- **Respects `prefers-reduced-motion`** — users who disable motion in their OS get a static grid (no float, no entrance animation).

### Files to change

1. **`src/styles.css`** — add three keyframes and helper classes:
   - `@keyframes float-soft` (translateY + tiny rotate, 6s ease-in-out infinite, alternate)
   - `@keyframes card-rise` (opacity 0→1, translateY 16px→0, 600ms)
   - `.menu-card` applies `card-rise` once; `.menu-float` applies `float-soft` to the image
   - `@media (prefers-reduced-motion: reduce)` disables both

2. **`src/routes/menu.tsx`** — apply the new classes:
   - Add `menu-card` to each `<article>` with an inline `style={{ animationDelay: \`${idx * 80}ms\` }}` for the cascade
   - Add `menu-float` to the `<img>` with a per-card delay (e.g. `${(idx % 5) * 0.6}s`) so floats are out of sync
   - Use a `key` that includes the active filter so cards re-trigger entry animation on filter change

### Out of scope

- No marquee, no hover tilt, no library installs (framer-motion not needed for this).
- No backend or data changes.
