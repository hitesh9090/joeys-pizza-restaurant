
CREATE TABLE public.menu_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  price_small NUMERIC(10,2),
  price_large NUMERIC(10,2) NOT NULL,
  category TEXT NOT NULL,
  veg BOOLEAN NOT NULL DEFAULT true,
  popular BOOLEAN NOT NULL DEFAULT false,
  badge TEXT,
  image_url TEXT,
  available BOOLEAN NOT NULL DEFAULT true,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number SERIAL UNIQUE,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  fulfillment TEXT NOT NULL DEFAULT 'delivery',
  address TEXT,
  notes TEXT,
  items JSONB NOT NULL,
  subtotal NUMERIC(10,2) NOT NULL,
  total NUMERIC(10,2) NOT NULL,
  payment_method TEXT NOT NULL,
  payment_status TEXT NOT NULL DEFAULT 'pending',
  order_status TEXT NOT NULL DEFAULT 'new',
  stripe_session_id TEXT,
  notified BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.menu_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Menu is public for reading
CREATE POLICY "menu items are viewable by everyone"
  ON public.menu_items FOR SELECT USING (available = true);

-- Orders: anyone can insert (public ordering, no auth required)
CREATE POLICY "anyone can place an order"
  ON public.orders FOR INSERT WITH CHECK (true);

-- Orders: only the just-inserted row can be returned (id-based read by owner)
CREATE POLICY "anyone can view an order by id"
  ON public.orders FOR SELECT USING (true);

ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;
