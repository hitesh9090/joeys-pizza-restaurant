
DROP POLICY "anyone can view an order by id" ON public.orders;

ALTER TABLE public.orders
  ADD CONSTRAINT orders_name_len CHECK (char_length(customer_name) BETWEEN 1 AND 120),
  ADD CONSTRAINT orders_phone_len CHECK (char_length(customer_phone) BETWEEN 5 AND 20),
  ADD CONSTRAINT orders_addr_len CHECK (address IS NULL OR char_length(address) <= 500),
  ADD CONSTRAINT orders_notes_len CHECK (notes IS NULL OR char_length(notes) <= 500),
  ADD CONSTRAINT orders_total_pos CHECK (total > 0 AND subtotal > 0),
  ADD CONSTRAINT orders_items_size CHECK (jsonb_typeof(items) = 'array' AND jsonb_array_length(items) BETWEEN 1 AND 50),
  ADD CONSTRAINT orders_payment_method_chk CHECK (payment_method IN ('cash','card')),
  ADD CONSTRAINT orders_fulfillment_chk CHECK (fulfillment IN ('delivery','pickup'));
