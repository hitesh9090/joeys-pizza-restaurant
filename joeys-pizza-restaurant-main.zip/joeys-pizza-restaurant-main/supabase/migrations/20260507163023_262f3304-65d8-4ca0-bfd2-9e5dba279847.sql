-- No schema change needed; order_status is text. Just documenting accepted values via app code.
SELECT 1;