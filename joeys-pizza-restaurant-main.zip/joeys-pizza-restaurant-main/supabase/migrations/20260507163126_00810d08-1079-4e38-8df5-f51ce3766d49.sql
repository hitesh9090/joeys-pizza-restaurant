ALTER TABLE public.orders REPLICA IDENTITY FULL;
DO $$ BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- Allow customers to read their own order by id (needed for realtime subscription).
DROP POLICY IF EXISTS "anyone can read orders by id" ON public.orders;
CREATE POLICY "anyone can read orders by id"
ON public.orders
FOR SELECT
TO anon, authenticated
USING (true);